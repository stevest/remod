$t1=time();

open(F, "files_to_be_edited.txt");
while($line=<F>)
{
	chomp $line;
	system("python second_run.py /Users/bozelosp/Dropbox/remod/CNG_modified/ $line who_basal_terminal 0 none none none none none -25");
}

$t2=time();

$dt=$t2-$t1;

print "Elapsed time: $dt seconds\n";
