import re
from math import sqrt
from random import randint
import sys

import numpy as np
from random import uniform, randrange
from math import cos, sin, pi, sqrt, radians, degrees

def total_length(dlist, dist, soma_index): #soma_included

	t_length=0

	for k in range(len(soma_index)-1):

		current=soma_index[k]
		next=soma_index[k+1]

		t_length+=distance(next[2], current[2], next[3], current[3], next[4], current[4])

	for dend in dlist:
		t_length+=dist[dend]
	return t_length

def total_area(dlist, area, soma_index): #soma_included

	t_area=0

	n=0
	for k in range(len(soma_index)-1):

		current=soma_index[k]
		next=soma_index[k+1]

		diam=next[5]
		di=distance(next[2], current[2], next[3], current[3], next[4], current[4])
		a=2*pi*diam*di+2*pi*(diam**2)
		t_area+=a

		if n>0:
			circle_surface=-pi*(diam**2)
			t_area+=circle_surface
		n+=1

	for dend in dlist:
		t_area+=area[dend]

	return t_area

def path_length(dlist, path, dist):
	plength=dict()
	for dend in dlist:
		d=0
		for i in path[dend]:
			d+=dist[i]
		plength[dend]=d
	return plength

def branch_order(dlist, path):
	bo=dict()
	for dend in dlist:
		bo[dend]=len(path[dend])-1
	return bo

def bo_frequency(dlist, bo):

	orders=[]
	for dend in dlist:
		orders.append(bo[dend])

	bo_min=1 # min(orders)
	bo_max=max(orders)

	bo_freq={}

	for i in range(bo_min, bo_max+1):
		k=0
		for order in orders:
			if order==i:
				k+=1
		bo_freq[i]=k

	return bo_freq, bo_max

def bo_dlength(dlist, bo, bo_max, dist):

	bo_dlen={}
	for i in range(1, bo_max+1):

		k=0
		add_length=0

		for dend in dlist:
			if i==bo[dend]:
				k+=1
				add_length+=dist[dend]
				#print str(dend) + ' ' + str(bo[dend]) + ' ' + str(dist[dend])

		if k!=0:
			bo_dlen[i]=add_length/k

	return bo_dlen

def bo_plength(dlist, bo, bo_max, plength):

	bo_plen={}
	for i in range(1, bo_max+1):

		k=0
		add_length=0

		for dend in dlist:
			if i==bo[dend]:
				k+=1
				add_length+=plength[dend]
				#print str(dend) + ' ' + str(bo[dend]) + ' ' + str(dist[dend])

		if k!=0:
			bo_plen[i]=add_length/k

	return bo_plen

def distance(x1,x2,y1,y2,z1,z2): #returns the euclidean distance between two 3d points

	dist = sqrt((x2-x1)**2 + (y2-y1)**2 + (z2-z1)**2)
	return dist

def sholl(dend_list, dend_add3d, bo, con, soma_index, radius):
	
	sholl_list=dict()

	for i in soma_index:
		if i[1]==1:
			xr=i[2]
			yr=i[3]
			zr=i[4]
	
	for val in np.arange(radius, 10000, radius):

		intersection=0

		for dend in dend_list:

			k=0

			for i in dend_add3d[dend]:

				if k==0:
					pass

				else:
					previous_dist=mydist

				x=i[2]
				y=i[3]
				z=i[4]

				mydist=distance(xr,x,yr,y,zr,z)

				if k==0:
					pass

				else:

					if val>previous_dist and val<mydist:

						intersection+=1

				k+=1

		if intersection==0:
			break

		sholl_list[val]=intersection

	return sholl_list